﻿namespace fitSharp.Samples {
    public class EchoFixture {
        public double EchoDouble(double value) { return value; }
    }
}
