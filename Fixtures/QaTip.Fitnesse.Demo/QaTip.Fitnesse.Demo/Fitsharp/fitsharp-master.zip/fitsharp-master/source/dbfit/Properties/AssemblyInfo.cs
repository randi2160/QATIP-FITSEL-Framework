﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DbFit for fitSharp")]
[assembly: AssemblyDescription("DbFit. This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 2.")]
[assembly: AssemblyProduct("fitSharp")]
[assembly: AssemblyCopyright("Copyright © 2007 Gojko Adzic, 2015 Syterra Software Inc. All rights reserved.")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("2.4.*")]
