﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Test target for fitSharp")]
[assembly: AssemblyDescription("fitSharp. The use and distribution terms for this software are covered by the Common Public License 1.0.")]
[assembly: AssemblyProduct("fitSharp")]
[assembly: AssemblyCopyright("Copyright © 2015 Syterra Software Inc. All rights reserved.")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("2.4.*")]
