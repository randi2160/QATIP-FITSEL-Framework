﻿namespace fitSharp.TestTarget {
    public class SampleTargetType {}
}