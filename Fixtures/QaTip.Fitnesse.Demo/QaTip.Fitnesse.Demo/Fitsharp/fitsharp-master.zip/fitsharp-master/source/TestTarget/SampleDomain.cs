﻿namespace fitSharp.TestTarget {
    public class SampleDomain {
    }
}