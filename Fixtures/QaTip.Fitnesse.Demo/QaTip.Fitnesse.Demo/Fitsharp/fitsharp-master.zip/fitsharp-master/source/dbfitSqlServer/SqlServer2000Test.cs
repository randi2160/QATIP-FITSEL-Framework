namespace dbfit{
	public class SqlServer2000Test:DatabaseTest {
        public SqlServer2000Test()
            : base(new SqlServer2000Environment())
        {
		
		}
	}
}
