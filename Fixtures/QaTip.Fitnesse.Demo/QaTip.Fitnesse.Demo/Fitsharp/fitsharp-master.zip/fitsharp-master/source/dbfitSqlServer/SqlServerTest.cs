namespace dbfit{
	public class SqlServerTest:DatabaseTest {
		public SqlServerTest(): base(new SqlServerEnvironment()){
		
		}
	}
}
