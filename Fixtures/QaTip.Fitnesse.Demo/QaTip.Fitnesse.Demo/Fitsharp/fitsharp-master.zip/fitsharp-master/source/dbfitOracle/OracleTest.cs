namespace dbfit{
	public class OracleTest:DatabaseTest {
		public OracleTest(): base(new OracleEnvironment()){
		
		}
	}
}
